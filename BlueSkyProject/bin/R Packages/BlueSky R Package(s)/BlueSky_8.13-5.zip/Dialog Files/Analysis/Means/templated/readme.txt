After Installing BSkyOneSmTTest rename in Dialog Installer as "Multi Variable One Sample T-Test"

After Installing "BSkyIndSmTTest" rename in Dialog Installer as "Multi Variable Independent Sample T-Test"


This is needed because "BSkyOneSmTTest" is the method name in BlueSky R package and it is must to have XAML and XML file installed with that name only. When you rename it to "Multi Variable One Sample T-Test" its only for the menu but behind the scenes in "Config" their name matches to the method name in BlueSky R package.

Same goes for "BSkyIndSmTTest"

